# LightBlock v2 Backend

- REST API with Flask
- Adjustable difficulty
- ECDSA encryption
