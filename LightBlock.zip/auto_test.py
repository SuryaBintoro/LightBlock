
import requests
import json
from ecdsa import SigningKey, SECP256k1
from blockchain import Transaction
from wallet import Wallet

# 1. Buat Wallet Baru
wallet = Wallet()
private_key_hex = wallet.get_private_key_hex()
public_key_hex = wallet.get_public_key_hex()
print("=== Wallet Baru Dibuat ===")
print("Private Key:", private_key_hex)
print("Public Key (alamat dompet):", public_key_hex)

# 2. Buat Transaksi ke penerima (contoh random recipient)
recipient_address = "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
amount = 20

# 3. Buat transaksi & sign
tx = Transaction(public_key_hex, recipient_address, amount)
private_key = SigningKey.from_string(bytes.fromhex(private_key_hex), curve=SECP256k1)
tx.sign_transaction(private_key)

# 4. Kirim transaksi ke node
tx_data = {
    "sender": tx.sender,
    "recipient": tx.recipient,
    "amount": tx.amount,
    "signature": tx.signature
}

response = requests.post("http://localhost:5000/transactions/new", json=tx_data)
print("Transaksi Dikirim:", response.text)

# 5. Mine blok baru
print("Menambang blok...")
mine_response = requests.get(f"http://localhost:5000/mine?miner={public_key_hex}")
print(mine_response.text)

# 6. Lihat blockchain
print("=== Blockchain Saat Ini ===")
chain_response = requests.get("http://localhost:5000/chain")
chain = chain_response.json()
for block in chain:
    print(f"Block #{block['index']} - Hash: {block['hash']}")
    for tx in block['transactions']:
        print(f"  From: {tx['sender'][:10]}... To: {tx['recipient'][:10]}... Amount: {tx['amount']}")
    print("="*50)
