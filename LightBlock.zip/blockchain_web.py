
from flask import Flask, request, render_template, redirect, url_for
from wallet import Wallet
from blockchain import Transaction
from ecdsa import SigningKey, SECP256k1
import requests

app = Flask(__name__)
current_wallet = None

@app.route('/')
def home():
    global current_wallet
    return render_template('index.html', wallet=current_wallet)

@app.route('/create_wallet', methods=['POST'])
def create_wallet():
    global current_wallet
    current_wallet = Wallet()
    return redirect(url_for('home'))

@app.route('/send_transaction', methods=['POST'])
def send_transaction():
    global current_wallet
    recipient = request.form['recipient']
    amount = float(request.form['amount'])

    tx = Transaction(current_wallet.get_public_key_hex(), recipient, amount)
    tx.sign_transaction(current_wallet.private_key)

    tx_data = {
        "sender": tx.sender,
        "recipient": tx.recipient,
        "amount": tx.amount,
        "signature": tx.signature
    }

    requests.post("http://localhost:5000/transactions/new", json=tx_data)
    return redirect(url_for('home'))

@app.route('/mine', methods=['POST'])
def mine():
    global current_wallet
    requests.get(f"http://localhost:5000/mine?miner={current_wallet.get_public_key_hex()}")
    return redirect(url_for('home'))

@app.route('/chain')
def show_chain():
    chain_data = requests.get("http://localhost:5000/chain").json()
    return render_template('chain.html', chain=chain_data)

if __name__ == '__main__':
    app.run(port=5001, debug=True)
