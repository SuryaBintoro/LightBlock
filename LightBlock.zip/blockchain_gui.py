
import tkinter as tk
from tkinter import messagebox, scrolledtext
from wallet import Wallet
from blockchain import Transaction
from ecdsa import SigningKey, SECP256k1
import requests

class BlockchainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Blockchain Sederhana")
        
        self.wallet = None

        tk.Button(root, text="Buat Wallet Baru", command=self.create_wallet).pack(pady=5)
        
        tk.Label(root, text="Alamat Penerima:").pack()
        self.recipient_entry = tk.Entry(root, width=60)
        self.recipient_entry.pack()

        tk.Label(root, text="Jumlah:").pack()
        self.amount_entry = tk.Entry(root, width=20)
        self.amount_entry.pack()

        tk.Button(root, text="Kirim Transaksi", command=self.send_transaction).pack(pady=5)
        tk.Button(root, text="Mine Blok", command=self.mine_block).pack(pady=5)
        tk.Button(root, text="Lihat Blockchain", command=self.show_chain).pack(pady=5)

        self.output_text = scrolledtext.ScrolledText(root, width=80, height=20)
        self.output_text.pack()

    def create_wallet(self):
        self.wallet = Wallet()
        self.output_text.insert(tk.END, f"Wallet Dibuat:
Private Key: {self.wallet.get_private_key_hex()}
Public Key: {self.wallet.get_public_key_hex()}

")

    def send_transaction(self):
        if not self.wallet:
            messagebox.showwarning("Warning", "Buat wallet terlebih dahulu!")
            return

        recipient = self.recipient_entry.get()
        amount = self.amount_entry.get()
        try:
            amount = float(amount)
        except:
            messagebox.showwarning("Warning", "Jumlah tidak valid!")
            return

        tx = Transaction(self.wallet.get_public_key_hex(), recipient, amount)
        tx.sign_transaction(self.wallet.private_key)

        tx_data = {
            "sender": tx.sender,
            "recipient": tx.recipient,
            "amount": tx.amount,
            "signature": tx.signature
        }
        response = requests.post("http://localhost:5000/transactions/new", json=tx_data)
        self.output_text.insert(tk.END, f"Transaksi dikirim: {response.text}

")

    def mine_block(self):
        if not self.wallet:
            messagebox.showwarning("Warning", "Buat wallet terlebih dahulu!")
            return
        response = requests.get(f"http://localhost:5000/mine?miner={self.wallet.get_public_key_hex()}")
        self.output_text.insert(tk.END, f"Mining: {response.text}

")

    def show_chain(self):
        response = requests.get("http://localhost:5000/chain")
        chain = response.json()
        self.output_text.insert(tk.END, "=== Blockchain Saat Ini ===
")
        for block in chain:
            self.output_text.insert(tk.END, f"Block #{block['index']} - Hash: {block['hash']}
")
            for tx in block['transactions']:
                self.output_text.insert(tk.END, f"  From: {tx['sender'][:10]}... To: {tx['recipient'][:10]}... Amount: {tx['amount']}
")
            self.output_text.insert(tk.END, "="*50 + "
")

if __name__ == "__main__":
    root = tk.Tk()
    app = BlockchainApp(root)
    root.mainloop()
