
# LightBlock

**LightBlock** adalah proyek blockchain sederhana yang dibuat dengan Python, lengkap dengan antarmuka GUI dan web frontend.  
Proyek ini cocok untuk belajar memahami konsep blockchain, transaksi, mining, dan memvisualisasikan blockchain secara sederhana.

## Fitur
- Pembuatan wallet dengan private & public key
- Mengirim transaksi
- Mining blok baru
- Melihat blockchain
- GUI berbasis Tkinter
- Web frontend berbasis Flask

## Struktur Proyek
```
LightBlock/
├─ blockchain_web.py
├─ blockchain_gui.py
├─ auto_test.py
├─ templates/
│  ├─ index.html
│  └─ chain.html
├─ logo/
│  ├─ lightblock_logo.png
│  └─ lightblock_logo_transparent.png
└─ README.md
```

## Cara Menjalankan

### 1. Jalankan node backend (pastikan kamu sudah punya `node.py`, `blockchain.py`, dan `wallet.py`)
```bash
python node.py
```

### 2. Jalankan GUI
```bash
python blockchain_gui.py
```

### 3. Jalankan web frontend
```bash
python blockchain_web.py
```
Buka di browser: `http://localhost:5001`

### 4. Jalankan auto test script (opsional)
```bash
python auto_test.py
```

---
**Logo by ChatGPT + DALL·E.**  
