# LightBlock GUI with PyQt5 (dummy placeholder)
