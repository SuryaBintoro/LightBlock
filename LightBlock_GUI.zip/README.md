# LightBlock GUI

- Jalankan dengan `python lightblock_gui.py`
- Pastikan backend sudah aktif.
